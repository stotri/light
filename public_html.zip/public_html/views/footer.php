



    <footer>
        <div class="row">
			<div class="col-sm-3 col-sm-offset-9 text-right">ИП Денис Игоревич Пышный <br>
                                                УНП 790836120 <br>
                                                Тел.: <a href="tel:+375292508209">+375 (29) 250-82-09</a>
            </div>
            <div class="col-sm-12 text-center" style="margin-top: 20px;"><i>Copyright © Балабушко Д. А. </i><!--LiveInternet counter--><script type="text/javascript">
                                                                                                            document.write("<a href='//www.liveinternet.ru/click' "+
                                                                                                            "target=_blank><img src='//counter.yadro.ru/hit?t44.3;r"+
                                                                                                            escape(document.referrer)+((typeof(screen)=="undefined")?"":
                                                                                                            ";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
                                                                                                            screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
                                                                                                            ";h"+escape(document.title.substring(0,150))+";"+Math.random()+
                                                                                                            "' alt='' title='LiveInternet' "+
                                                                                                            "border='0' width='31' height='31'><\/a>")
                                                                                                            </script><!--/LiveInternet-->
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 text-center">
                <i><small>По вопросам приобритения сайтов: </small> +37529-5541261</i>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 text-center">
                <i>Email: balabushko@lenta.ru</i>
            </div>
        </div>
    </footer>
    </div>
  </body>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script
        src="https://code.jquery.com/jquery-3.2.1.js"
        integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
        crossorigin="anonymous"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.js"></script>    
    <script src="js/active_item.js"></script>
    <script src="js/menu.js"></script>
    <script src="js/tooltip.js" type="text/javascript"></script>    

</html>